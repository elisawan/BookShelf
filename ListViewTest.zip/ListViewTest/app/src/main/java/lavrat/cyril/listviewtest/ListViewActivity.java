package lavrat.cyril.listviewtest;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static java.security.AccessController.getContext;

public class ListViewActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        mListView = (ListView) findViewById(R.id.list_of_owner);

        List<Owner> owners = genererOwner();

        OwnerAdapter adapter = new OwnerAdapter(ListViewActivity.this, owners);
        mListView.setAdapter(adapter);
    }

    private List<Owner> genererOwner(){
        List<Owner> owners = new ArrayList<Owner>();
        owners.add(new Owner(Color.BLACK, "Williams", "Very good Book !!","3 km"));
        owners.add(new Owner(Color.BLUE, "Giovanna", "Questo libri e perfetto!","10 km"));
        owners.add(new Owner(Color.GREEN, "Paul", "Miam!","11 km"));
        owners.add(new Owner(Color.RED, "Mathieu", "Heuuu...","12 km"));
        owners.add(new Owner(Color.GRAY, "Domenico", "Non so... Haa si! perfetto!!","13 km"));
        owners.add(new Owner(Color.BLACK, "Williams", "Very good Book !!","3 km"));
        owners.add(new Owner(Color.BLUE, "Giovanna", "Questo libri e perfetto!","10 km"));
        owners.add(new Owner(Color.GREEN, "Paul", "Miam!","11 km"));
        owners.add(new Owner(Color.RED, "Mathieu", "Heuuu...","12 km"));
        owners.add(new Owner(Color.GRAY, "Domenico", "Non so... Haa si! perfetto!!","13 km"));
        owners.add(new Owner(Color.BLACK, "Williams", "Very good Book !!","3 km"));
        owners.add(new Owner(Color.BLUE, "Giovanna", "Questo libri e perfetto!","10 km"));
        owners.add(new Owner(Color.GREEN, "Paul", "Miam!","11 km"));
        owners.add(new Owner(Color.RED, "Mathieu", "Heuuu...","12 km"));
        owners.add(new Owner(Color.GRAY, "Domenico", "Non so... Haa si! perfetto!!","13 km"));
        owners.add(new Owner(Color.BLACK, "Williams", "Very good Book !!","3 km"));
        owners.add(new Owner(Color.BLUE, "Giovanna", "Questo libri e perfetto!","10 km"));
        owners.add(new Owner(Color.GREEN, "Paul", "Miam!","11 km"));
        owners.add(new Owner(Color.RED, "Mathieu", "Heuuu...","12 km"));
        owners.add(new Owner(Color.GRAY, "Domenico", "Non so... Haa si! perfetto!!","13 km"));
        return owners;
    }
}

class OwnerViewHolder{
    public TextView pseudo;
    public TextView text;
    public ImageView avatar;
}


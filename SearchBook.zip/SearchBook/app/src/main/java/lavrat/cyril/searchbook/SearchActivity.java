package lavrat.cyril.searchbook;

import android.os.Build;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ListView;

public class SearchActivity extends AppCompatActivity {

    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    TabPageAdapter tabPageAdapter;
    TabItem tabSearchByAll;
    TabItem tabSearchByTitle;
    TabItem tabSearchByAuthor;
    TabItem tabSearchByPublisher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getResources().getString(R.string.app_name));

        tabSearchByAll = findViewById(R.id.tabSearchByAll);
        tabSearchByTitle = findViewById(R.id.tabSearchByTitle);
        tabSearchByAuthor = findViewById(R.id.tabSearchByAuthor);
        tabSearchByPublisher = findViewById(R.id.tabSearchByPublisher);
        tabLayout = findViewById(R.id.tablayout);
        viewPager = findViewById(R.id.SearchViewPager);

        tabPageAdapter = new TabPageAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(tabPageAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
                if(tab.getPosition()==1){
                    toolbar.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchAll));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchAll));
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(
                                SearchActivity.this, R.color.colorTabSearchAll));
                    }
                }else if (tab.getPosition()==2){
                    toolbar.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchTitle));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchTitle));
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(
                                SearchActivity.this, R.color.colorTabSearchTitle));
                    }
                }else if (tab.getPosition()==3){
                    toolbar.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchAuthor));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchAuthor));
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(
                                SearchActivity.this, R.color.colorTabSearchAuthor));
                    }
                }else{
                    toolbar.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchPublisher));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(
                            SearchActivity.this, R.color.colorTabSearchPublisher));
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(
                                SearchActivity.this, R.color.colorTabSearchPublisher));
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
